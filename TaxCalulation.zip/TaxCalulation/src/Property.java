
public class Property implements Taxable
{
	private static int nextId = 1;
    private int id;
	private double builtUpArea;
    private double ageFactor;
    private double baseValue;
    private boolean isInCity;
    private double tax;
    
    public Property() 
    {
		
	}
    
    public Property(double builtUpArea, double ageFactor, double baseValue, boolean isInCity) 
    {
    	this.id = nextId++;
        this.builtUpArea = builtUpArea;
        this.ageFactor = ageFactor;
        this.baseValue = baseValue;
        this.isInCity = isInCity;
    }

    public double getBuiltUpArea() 
    {
		return builtUpArea;
	}

	public void setBuiltUpArea(double builtUpArea) 
	{
		this.builtUpArea = builtUpArea;
	}

	public double getAgeFactor() 
	{
		return ageFactor;
	}

	public void setAgeFactor(double ageFactor) 
	{
		this.ageFactor = ageFactor;
	}

	public double getBaseValue() 
	{
		return baseValue;
	}
	
	public int getID() 
	{
		return id;
	}

	public void setBaseValue(double baseValue) 
	{
		this.baseValue = baseValue;
	}

	public boolean isInCity() 
	{
		return isInCity;
	}

	public void setInCity(boolean isInCity) 
	{
		this.isInCity = isInCity;
	}

	public double getTax() 
	{
		return tax;
	}

	public void setTax(double tax) 
	{
		this.tax = tax;
	}   

	@Override
    public double calculateTax() 
	{
        if (isInCity)
        {
        	tax = (builtUpArea * ageFactor * baseValue) + (0.5 * builtUpArea);
        }
        else
            tax = builtUpArea * ageFactor * baseValue;
        return tax;
    }

    @Override
    public String toString() 
    {
        return "Property ID = " + id + "\nBuilt Up Area = " + builtUpArea + "\nAge Factor = " + ageFactor
                + "\nBase Value = " + baseValue + "\nIn City = " + isInCity + "\nProperty Tax = " + tax;
    }
}
