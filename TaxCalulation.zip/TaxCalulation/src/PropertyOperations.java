import java.util.*;

public class PropertyOperations 
{
	private List<Property> properties = new ArrayList<>();
    public void handlePropertyMenu(Scanner scanner) 
    {
        int propertyChoice;
        do 
        {
            displayPropertyMenu();
            propertyChoice = getUserNumericInput(scanner);
            switch (propertyChoice) 
            {
                case 1:
                    addProperty(scanner);
                    break;
                case 2:
                    calculatePropertyTax();
                    break;
                case 3:
                	List<Property> properties = getAllProperties();
                	System.out.println("\nPROPERTY LIST:");
                    System.out.println("------------------------------------------------------------------------------------------------------");
                    System.out.printf("%-5s%-20s%-20s%-20s%-20s%-20s%n", "ID", "Built-up Area", "Age Factor", "Base Value", "Is In City", "Property Tax");
                    System.out.println("------------------------------------------------------------------------------------------------------");
                    for (int i = 0; i < properties.size(); i++) 
                    {
                        Property property = properties.get(i);
                        System.out.printf("%-5d%-20.2f%-20.2f%-20.2f%-20s%-20.2f%n", property.getID(),
                                property.getBuiltUpArea(), property.getAgeFactor(), property.getBaseValue(), property.isInCity(), property.calculateTax());
                    }
                    System.out.println("------------------------------------------------------------------------------------------------------");
                case 4:
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (propertyChoice != 4);
    }

    private void displayPropertyMenu() 
    {
        System.out.println("\nPROPERTY MENU:");
        System.out.println("1. ADD PROPERTY DETAILS");
        System.out.println("2. CALCULATE PROPERTY TAX");
        System.out.println("3. DISPLAY ALL PROPERTIES");
        System.out.println("4. BACK TO MAIN MENU");
        System.out.print("Enter your choice: ");
    }

    private void addProperty(Scanner scanner) 
    {
        try 
        {
            System.out.print("Enter built-up area: ");
            double builtUpArea = scanner.nextDouble();
            System.out.print("Enter age factor: ");
            double ageFactor = scanner.nextDouble();
            System.out.print("Enter base value: ");
            double baseValue = scanner.nextDouble();
            if (baseValue <= 0) 
            {
                throw new IllegalArgumentException("Base value must be a positive number.");
            }
            System.out.print("Is property in city? (Y/N): ");
            boolean isInCity = scanner.next().equalsIgnoreCase("Y");
            Property property = new Property(builtUpArea, ageFactor, baseValue, isInCity);
            properties.add(property);
            System.out.println("Property added successfully!");
        } 
        catch (InputMismatchException e) 
        {
            System.out.println("Invalid input format. Please enter a valid numeric value.");
            scanner.nextLine(); // Clear the buffer
        } 
        catch (IllegalArgumentException e) 
        {
            System.out.println(e.getMessage());
        }
    }

    private void calculatePropertyTax() 
    {
        if (properties.isEmpty()) 
        {
            System.out.println("No properties added yet.");
            return;
        }
        for (Property property : properties) 
        {
            double tax = property.calculateTax();
            System.out.printf("Property Tax: %.2f%n", tax);
        }
    }

    List<Property> getAllProperties() 
    {
        if (properties.isEmpty()) 
        {
            System.out.println("No properties added yet.");
            return null;
        }
        else
        {
        	return properties;
        }
    }

    private static int getUserNumericInput(Scanner scanner) 
    {
        while (!scanner.hasNextInt()) 
        {
            System.out.print("Invalid input. Please enter a numeric value: ");
            scanner.next(); // Clear the buffer
        }
        return scanner.nextInt();
    }
}
