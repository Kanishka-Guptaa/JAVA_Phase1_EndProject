import java.util.List;
import java.util.Scanner;

public class TaxMain 
{
	static PropertyOperations propertyOperations = new PropertyOperations();
    static VehicleOperations vehicleOperations = new VehicleOperations();
	public static void main(String[] args) 
	{        
        Scanner scanner = new Scanner(System.in);
        int mainChoice;
        System.out.println("\t****Welcome to TAX CALCULATION Application****\t");
        do 
        {
            displayMainMenu();
            mainChoice = getUserNumericInput(scanner);
            switch (mainChoice) 
            {
                case 1:
                    propertyOperations.handlePropertyMenu(scanner);
                    break;
                case 2:
                    vehicleOperations.handleVehicleMenu(scanner);
                    break;
                case 3:
                	displaySummary();
                    break;
                case 4:
                    System.out.println("THANK YOU!!!\nVISIT AGAIN....");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }while (mainChoice != 4);
    }

    private static void displayMainMenu() 
    {
        System.out.println("1. PROPERTY TAX");
        System.out.println("2. VEHICLE TAX");
        System.out.println("3. TOTAL");
        System.out.println("4. EXIT");
        System.out.print("Enter your choice: ");
    }

    private static int getUserNumericInput(Scanner scanner) 
    {
        while (!scanner.hasNextInt()) 
        {
            System.out.print("Invalid input. Please enter a numeric value: ");
            scanner.next(); // Clear the buffer
        }
        return scanner.nextInt();
    }

    private static void displaySummary() 
    {
    	List<Property> properties = propertyOperations.getAllProperties();
        List<Vehicle> vehicles = vehicleOperations.getAllVehicles();
        int numProperties = properties.size();
        int numVehicles = vehicles.size();

        double totalPropertyTax = 0;
        double totalVehicleTax = 0;
        for (Property property : properties) 
        {
            totalPropertyTax += property.calculateTax();
        }
        for (Vehicle vehicle : vehicles) 
        {
            totalVehicleTax += vehicle.calculateTax();
        }
        double totalTax = totalPropertyTax + totalVehicleTax;

        System.out.println("\nSUMMARY:");
        System.out.println("---------------------------------------------------------");
        System.out.printf("%-20s%-20s%-20s%n", "Particular", "Quantity", "Total Tax");
        System.out.println("---------------------------------------------------------");
        System.out.printf("%-20s%-20d%-20.2f%n", "Property Tax", numProperties, totalPropertyTax);
        System.out.printf("%-20s%-20d%-20.2f%n", "Vehicle Tax", numVehicles, totalVehicleTax);
        System.out.println("---------------------------------------------------------");
        System.out.printf("%-20s%-20d%-20.2f%n", "Overall Total", numProperties + numVehicles, totalTax);
        System.out.println("---------------------------------------------------------");
    }

}


