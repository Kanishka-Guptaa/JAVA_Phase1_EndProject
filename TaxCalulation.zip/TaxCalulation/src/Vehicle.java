
public class Vehicle implements Taxable
{
	private static int nextId = 1;
    private int id;
    private String registrationNumber;
    private String brand;
    private double purchaseCost;
    private double maxVelocity;
    private int capacity;
    private int type;
    private String vtype;
    private double tax;
    
    public Vehicle() 
    {
	}

    public String getRegistrationNumber() 
    {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) 
	{
		this.registrationNumber = registrationNumber;
	}

	public String getBrand() 
	{
		return brand;
	}

	public void setBrand(String brand) 
	{
		this.brand = brand;
	}

	public double getPurchaseCost() 
	{
		return purchaseCost;
	}

	public void setPurchaseCost(double purchaseCost) 
	{
		this.purchaseCost = purchaseCost;
	}

	public double getMaxVelocity() 
	{
		return maxVelocity;
	}

	public void setMaxVelocity(double maxVelocity) 
	{
		this.maxVelocity = maxVelocity;
	}

	public int getCapacity() 
	{
		return capacity;
	}

	public void setCapacity(int capacity) 
	{
		this.capacity = capacity;
	}

	public String getvType() 
	{
		return vtype;
	}

	public void setType(int type) 
	{
		this.type = type;
	}

	public Vehicle(String registrationNumber, String brand, double purchaseCost, double maxVelocity, int capacity, int type, String vtype) 
    {
		this.id = nextId++;
        this.registrationNumber = registrationNumber;
        this.brand = brand;
        this.purchaseCost = purchaseCost;
        this.maxVelocity = maxVelocity;
        this.capacity = capacity;
        this.type = type;
        this.vtype = vtype;
    }

    @Override
    public double calculateTax() 
    {
        tax = maxVelocity + capacity;
        switch (type) 
        {
            case 1: // Petrol
                tax += 0.10 * purchaseCost;
                break;
            case 2: // Diesel
                tax += 0.11 * purchaseCost;
                break;
            case 3: // CNG/LPG
                tax += 0.12 * purchaseCost;
                break;
        }
        return tax;
    }

    @Override
    public String toString() 
    {
        return "Vehicle ID = " + id + "\nRegistration Number = " + registrationNumber + "\nBrand = " + brand + "\nPurchase Cost = "
                + purchaseCost + "\nMaximum Velocity = " + maxVelocity + "\nCapacity = " + capacity + "\nVehicle Type = " + vtype + "\nVehicle Tax = " + tax +"\n";
    }

	
}
