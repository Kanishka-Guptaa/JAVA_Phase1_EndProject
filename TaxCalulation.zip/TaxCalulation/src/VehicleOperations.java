import java.util.*;

public class VehicleOperations 
{
	private List<Vehicle> vehicles = new ArrayList<>();

    public void handleVehicleMenu(Scanner scanner) 
    {
        int vehicleChoice;
        do 
        {
            displayVehicleMenu();
            vehicleChoice = getUserNumericInput(scanner);
            switch (vehicleChoice) 
            {
                case 1:
                    addVehicle(scanner);
                    break;
                case 2:
                    calculateVehicleTax();
                    break;
                case 3:
                	List<Vehicle> vehicles = getAllVehicles();
                	System.out.println("\nVEHICLE LIST:");
                    System.out.println("---------------------------------------------------------------------------");
                    System.out.printf("%-20s%-20s%-20s%-20s%-20s%-20s%-20s%n", "Reg. Number", "Brand", "Purchase Cost", "Max Velocity", "Capacity", "Type", "Tax");
                    System.out.println("---------------------------------------------------------------------------");
                    for (Vehicle vehicle : vehicles) 
                    {
                        double tax = vehicle.calculateTax();
                        System.out.printf("%-20s%-20s%-20.2f%-20.2f%-20d%-20s%-20.2f%n",
                                vehicle.getRegistrationNumber(), vehicle.getBrand(), vehicle.getPurchaseCost(), vehicle.getMaxVelocity(), vehicle.getCapacity(), vehicle.getvType(), tax);
                    }
                    System.out.println("---------------------------------------------------------------------------");
                    break;
                case 4:
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }while (vehicleChoice != 4);
    }

    private void displayVehicleMenu() 
    {
        System.out.println("\nVEHICLE MENU:");
        System.out.println("1. ADD VEHICLE DETAILS");
        System.out.println("2. CALCULATE VEHICLE TAX");
        System.out.println("3. DISPLAY ALL VEHICLES");
        System.out.println("4. BACK TO MAIN MENU");
        System.out.print("Enter your choice: ");
    }

    private void addVehicle(Scanner scanner) 
    {
        try 
        {
            System.out.print("Enter registration number: ");
            String registrationNumber = scanner.next();
            if (!registrationNumber.matches("\\d{4}")) 
            {
                throw new IllegalArgumentException("Invalid registration number format. It must be a 4-digit numeric value.");
            }
            System.out.print("Enter brand: ");
            String brand = scanner.next();
            System.out.print("Enter purchase cost: ");
            double purchaseCost = scanner.nextDouble();
            if (purchaseCost <= 0 || purchaseCost < 50000 || purchaseCost > 1000000) 
            {
                throw new IllegalArgumentException("Purchase cost must be a positive number between INR 50000 and INR 1000000.");
            }
            System.out.print("Enter max velocity: ");
            double maxVelocity = scanner.nextDouble();
            if (maxVelocity <= 0 || maxVelocity < 120 || maxVelocity > 300) 
            {
                throw new IllegalArgumentException("Max velocity must be a positive number between 120kmph and 300kmph.");
            }
            System.out.print("Enter capacity (number of seats): ");
            int capacity = getUserNumericInput(scanner);
            if (capacity <= 0 || capacity < 2 || capacity > 50) 
            {
                throw new IllegalArgumentException("Capacity must be a positive number between 2 and 50.");
            }
            System.out.println("Select type of vehicle:");
            System.out.println("1. Petrol");
            System.out.println("2. Diesel");
            System.out.println("3. CNG/LPG");
            int type = getUserNumericInput(scanner);
            if (type < 1 || type > 3) 
            {
                throw new IllegalArgumentException("Invalid vehicle type. Please select a type between 1 and 3.");
            }
            String vtype;
            if(type == 1)
            {
            	vtype = "Petrol";
            }
            else if(type == 2)
            {
            	vtype = "Diesel";
            }
            else
            {
            	vtype = "CNG / LPG";
            }
            Vehicle vehicle = new Vehicle(registrationNumber, brand, purchaseCost, maxVelocity, capacity, type, vtype);
            vehicles.add(vehicle);
            System.out.println("Vehicle added successfully!");
        } 
        catch(InputMismatchException e) 
        {
            System.out.println("Invalid input format. Please enter a valid numeric value.");
            scanner.nextLine(); // Clear the buffer
        } 
        catch (IllegalArgumentException e) 
        {
            System.out.println(e.getMessage());
        }
    }

    private void calculateVehicleTax() 
    {
        if (vehicles.isEmpty()) 
        {
            System.out.println("No vehicles added yet.");
            return;
        }
        for (Vehicle vehicle : vehicles) 
        {
            double tax = vehicle.calculateTax();
            System.out.printf("Vehicle Tax: %.2f%n", tax);
        }
    }

    List<Vehicle> getAllVehicles() 
    {
        if (vehicles.isEmpty()) 
        {
            System.out.println("No vehicles added yet.");
            return null;
        }
        else
        {
        	return vehicles;
        }
    }

    private static int getUserNumericInput(Scanner scanner) 
    {
        while (!scanner.hasNextInt()) 
        {
            System.out.print("Invalid input. Please enter a numeric value: ");
            scanner.next(); // Clear the buffer
        }
        return scanner.nextInt();
    }
}
